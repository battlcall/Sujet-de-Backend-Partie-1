<?php

namespace App\Controller;

use App\Entity\Livre;
use App\Entity\Auteur;
use App\Entity\Categorie;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Attribute\Route;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

#[Route('/livres')]
class LivreController extends AbstractController
{
    #[Route('', name: 'livre_create', methods: ['POST'])]
    public function create(Request $request, EntityManagerInterface $em): JsonResponse
    {
        $data = json_decode($request->getContent(), true);
        if (!is_array($data)) {
            return new JsonResponse(['error'=>'JSON invalide'], 400);
        }

        foreach (['titre','datePublication','disponible','auteurId','categorieId'] as $f) {
            if (!array_key_exists($f, $data)) {
                return new JsonResponse(['error'=>"Champ manquant: $f"], 400);
            }
        }

        $auteur = $em->find(Auteur::class, (int)$data['auteurId']);
        $categorie = $em->find(Categorie::class, (int)$data['categorieId']);
        if (!$auteur || !$categorie) {
            return new JsonResponse(['error'=>'Auteur ou Catégorie introuvable'], 404);
        }

        $date = \DateTime::createFromFormat('Y-m-d', (string)$data['datePublication']);
        if (!$date) {
            return new JsonResponse(['error'=>'datePublication doit être au format Y-m-d'], 400);
        }

        $livre = (new Livre())
            ->setTitre((string)$data['titre'])
            ->setDatePublication($date)
            ->setDisponible((bool)$data['disponible'])
            ->setAuteur($auteur)
            ->setCategorie($categorie);

        $em->persist($livre);
        $em->flush();

        return new JsonResponse($this->toArray($livre), 201);
    }

    #[Route('/{id<\d+>}', name: 'livre_read', methods: ['GET'])]
    public function read(int $id, EntityManagerInterface $em): JsonResponse
    {
        $livre = $em->find(Livre::class, $id);
        if (!$livre) return new JsonResponse(['error'=>'Livre introuvable'], 404);
        return new JsonResponse($this->toArray($livre));
    }

    #[Route('/{id<\d+>}', name: 'livre_update', methods: ['PUT','PATCH'])]
    public function update(int $id, Request $request, EntityManagerInterface $em): JsonResponse
    {
        $livre = $em->find(Livre::class, $id);
        if (!$livre) return new JsonResponse(['error'=>'Livre introuvable'], 404);

        $data = json_decode($request->getContent(), true);
        if (!is_array($data)) return new JsonResponse(['error'=>'JSON invalide'], 400);

        if (isset($data['titre'])) $livre->setTitre((string)$data['titre']);
        if (isset($data['datePublication'])) {
            $d = \DateTime::createFromFormat('Y-m-d', (string)$data['datePublication']);
            if (!$d) return new JsonResponse(['error'=>'datePublication doit être Y-m-d'], 400);
            $livre->setDatePublication($d);
        }
        if (isset($data['disponible'])) $livre->setDisponible((bool)$data['disponible']);
        if (isset($data['auteurId'])) {
            $a = $em->find(Auteur::class, (int)$data['auteurId']);
            if (!$a) return new JsonResponse(['error'=>'Auteur introuvable'], 404);
            $livre->setAuteur($a);
        }
        if (isset($data['categorieId'])) {
            $c = $em->find(Categorie::class, (int)$data['categorieId']);
            if (!$c) return new JsonResponse(['error'=>'Catégorie introuvable'], 404);
            $livre->setCategorie($c);
        }

        $em->flush();
        return new JsonResponse($this->toArray($livre));
    }

    #[Route('/{id<\d+>}', name: 'livre_delete', methods: ['DELETE'])]
    public function delete(int $id, EntityManagerInterface $em): JsonResponse
    {
        $livre = $em->find(Livre::class, $id);
        if (!$livre) return new JsonResponse(['error'=>'Livre introuvable'], 404);

        $em->remove($livre);
        $em->flush();

        return new JsonResponse(null, 204);
    }

    private function toArray(Livre $l): array
    {
        return [
            'id' => $l->getId(),
            'titre' => $l->getTitre(),
            'datePublication' => $l->getDatePublication()->format('Y-m-d'),
            'disponible' => $l->isDisponible(),
            'auteur' => $l->getAuteur()?->getId(),
            'categorie' => $l->getCategorie()?->getId(),
        ];
    }
}

