<?php

namespace App\Controller;

use App\Repository\EmpruntRepository;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Routing\Attribute\Route;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

#[Route('/utilisateurs')]
class UtilisateurController extends AbstractController
{
    #[Route('/{id<\d+>}/emprunts/en-cours', name: 'utilisateur_emprunts_en_cours', methods: ['GET'])]
    public function empruntsEnCours(int $id, EmpruntRepository $repo): JsonResponse
    {
        $emprunts = $repo->actifsPourUtilisateurTrieAncienVersRecent($id);
        $list = array_map(function ($e) {
            return [
                'id' => $e->getId(),
                'livreId' => $e->getLivre()->getId(),
                'dateEmprunt' => $e->getDateEmprunt()->format('Y-m-d H:i:s')
            ];
        }, $emprunts);

        return new JsonResponse([
            'utilisateur' => $id,
            'count' => count($list),
            'emprunts' => $list
        ], 200);
    }
}

