<?php

namespace App\Controller;

use App\Repository\EmpruntRepository;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Attribute\Route;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

#[Route('/auteurs')]
class AuteurController extends AbstractController
{
    #[Route('/{id<\d+>}/livres-empruntes', name: 'auteur_livres_empruntes_entre', methods: ['GET'])]
    public function livresEmpruntesEntre(int $id, Request $request, EmpruntRepository $repo): JsonResponse
    {
        $du = \DateTime::createFromFormat('Y-m-d', (string)$request->query->get('du'));
        $au = \DateTime::createFromFormat('Y-m-d', (string)$request->query->get('au'));
        if (!$du || !$au) {
            return new JsonResponse(['error'=>'Paramètres "du" et "au" requis au format Y-m-d'], 400);
        }

        $emprunts = $repo->livresAuteurEmpruntesEntre($id, $du, $au);

        $result = array_map(function ($e) {
            return [
                'empruntId' => $e->getId(),
                'livreId' => $e->getLivre()->getId(),
                'titre' => $e->getLivre()->getTitre(),
                'dateEmprunt' => $e->getDateEmprunt()->format('Y-m-d H:i:s'),
                'dateRetour' => $e->getDateRetour()?->format('Y-m-d H:i:s'),
            ];
        }, $emprunts);

        return new JsonResponse($result, 200);
    }
}

