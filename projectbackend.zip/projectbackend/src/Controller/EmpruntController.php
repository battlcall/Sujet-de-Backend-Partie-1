<?php

namespace App\Controller;

use App\Entity\Emprunt;
use App\Entity\Livre;
use App\Entity\Utilisateur;
use App\Repository\EmpruntRepository;
use Doctrine\ORM\EntityManagerInterface;
use Psr\Log\LoggerInterface;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Attribute\Route;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

#[Route('/emprunts')]
class EmpruntController extends AbstractController
{
    #[Route('', name: 'emprunt_creer', methods: ['POST'])]
    public function emprunter(
        Request $request,
        EntityManagerInterface $em,
        EmpruntRepository $repo,
        LoggerInterface $logger
    ): JsonResponse {
        $data = json_decode($request->getContent(), true);
        if (!is_array($data)) return new JsonResponse(['error'=>'JSON invalide'], 400);
        foreach (['utilisateurId','livreId'] as $f) {
            if (!isset($data[$f])) return new JsonResponse(['error'=>"Champ manquant: $f"], 400);
        }

        $utilisateur = $em->find(Utilisateur::class, (int)$data['utilisateurId']);
        $livre = $em->find(Livre::class, (int)$data['livreId']);
        if (!$utilisateur || !$livre) return new JsonResponse(['error'=>'Utilisateur ou Livre introuvable'], 404);

        if (!$livre->isDisponible()) {
            return new JsonResponse(['error'=>'Livre déjà emprunté'], 409);
        }

        $nbActifs = $repo->countActifsPourUtilisateur($utilisateur->getId());
        if ($nbActifs >= 4) {
            return new JsonResponse(['error'=>"Un utilisateur ne peut pas emprunter plus de 4 livres"], 409);
        }

        $emprunt = (new Emprunt())
            ->setUtilisateur($utilisateur)
            ->setLivre($livre)
            ->setDateEmprunt(new \DateTime());

        $livre->setDisponible(false);

        $em->persist($emprunt);
        $em->flush();

        $logger->info('Emprunt créé', ['empruntId'=>$emprunt->getId(), 'utilisateur'=>$utilisateur->getId(), 'livre'=>$livre->getId()]);

        return new JsonResponse([
            'id' => $emprunt->getId(),
            'livre' => $livre->getId(),
            'utilisateur' => $utilisateur->getId(),
            'dateEmprunt' => $emprunt->getDateEmprunt()->format('Y-m-d H:i:s')
        ], 201);
    }

    #[Route('/{id<\d+>}/retour', name: 'emprunt_retour', methods: ['POST'])]
    public function rendre(
        int $id,
        EntityManagerInterface $em,
        LoggerInterface $logger
    ): JsonResponse {
        $emprunt = $em->find(Emprunt::class, $id);
        if (!$emprunt) return new JsonResponse(['error'=>'Emprunt introuvable'], 404);
        if ($emprunt->getDateRetour() !== null) {
            return new JsonResponse(['error'=>'Emprunt déjà clôturé'], 409);
        }

        $emprunt->setDateRetour(new \DateTime());
        $livre = $emprunt->getLivre();
        $livre->setDisponible(true);

        $em->flush();

        $logger->info('Livre rendu', ['empruntId'=>$emprunt->getId(), 'livre'=>$livre->getId()]);

        return new JsonResponse([
            'id' => $emprunt->getId(),
            'livre' => $livre->getId(),
            'dateRetour' => $emprunt->getDateRetour()->format('Y-m-d H:i:s')
        ], 200);
    }
}

