<?php

namespace App\Entity;

use App\Repository\EmpruntRepository;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: EmpruntRepository::class)]
class Emprunt
{
    #[ORM\Id, ORM\GeneratedValue, ORM\Column]
    private ?int $id = null;

    #[ORM\ManyToOne]
    #[ORM\JoinColumn(nullable: false)]
    private ?Livre $livre = null;

    #[ORM\ManyToOne]
    #[ORM\JoinColumn(nullable: false)]
    private ?Utilisateur $utilisateur = null;

    #[ORM\Column(type: 'datetime_mutable')]
    private \DateTimeInterface $dateEmprunt;

    #[ORM\Column(type: 'datetime_mutable', nullable: true)]
    private ?\DateTimeInterface $dateRetour = null;

    public function getId(): ?int { return $this->id; }
    public function getLivre(): ?Livre { return $this->livre; }
    public function setLivre(Livre $l): self { $this->livre = $l; return $this; }
    public function getUtilisateur(): ?Utilisateur { return $this->utilisateur; }
    public function setUtilisateur(Utilisateur $u): self { $this->utilisateur = $u; return $this; }
    public function getDateEmprunt(): \DateTimeInterface { return $this->dateEmprunt; }
    public function setDateEmprunt(\DateTimeInterface $d): self { $this->dateEmprunt = $d; return $this; }
    public function getDateRetour(): ?\DateTimeInterface { return $this->dateRetour; }
    public function setDateRetour(?\DateTimeInterface $d): self { $this->dateRetour = $d; return $this; }
    public function isActif(): bool { return $this->dateRetour === null; }
}

