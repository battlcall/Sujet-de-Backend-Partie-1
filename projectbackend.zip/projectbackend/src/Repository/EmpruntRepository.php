<?php

namespace App\Repository;

use App\Entity\Emprunt;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

class EmpruntRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, Emprunt::class);
    }

    public function countActifsPourUtilisateur(int $utilisateurId): int
    {
        return (int) $this->createQueryBuilder('e')
            ->select('COUNT(e.id)')
            ->where('e.utilisateur = :u')
            ->andWhere('e.dateRetour IS NULL')
            ->setParameter('u', $utilisateurId)
            ->getQuery()
            ->getSingleScalarResult();
    }

    public function actifsPourUtilisateurTrieAncienVersRecent(int $utilisateurId): array
    {
        return $this->createQueryBuilder('e')
            ->innerJoin('e.livre', 'l')->addSelect('l')
            ->where('e.utilisateur = :u')
            ->andWhere('e.dateRetour IS NULL')
            ->setParameter('u', $utilisateurId)
            ->orderBy('e.dateEmprunt', 'ASC')
            ->getQuery()
            ->getResult();
    }

    public function livresAuteurEmpruntesEntre(int $auteurId, \DateTimeInterface $du, \DateTimeInterface $au): array
    {
        return $this->createQueryBuilder('e')
            ->innerJoin('e.livre', 'l')->addSelect('l')
            ->innerJoin('l.auteur', 'a')
            ->where('a.id = :auteurId')
            ->andWhere('e.dateEmprunt BETWEEN :du AND :au')
            ->setParameter('auteurId', $auteurId)
            ->setParameter('du', $du->setTime(0,0,0))
            ->setParameter('au', $au->setTime(23,59,59))
            ->orderBy('e.dateEmprunt', 'ASC')
            ->getQuery()
            ->getResult();
    }
}

